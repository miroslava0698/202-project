/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangman;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.stream.Stream;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class Dictionary {
    
    private static final Logger LOGGER = Logger.getLogger(Dictionary.class.getName());
    private static final String WORDS_FILEPATH = "resource/words.txt";
    
    private ArrayList<String> words;
    private int size;

    
    public Dictionary() {
        this(WORDS_FILEPATH);
    }
    public Dictionary(String filePath) {
        words = new ArrayList<>();
        fillFromFile(filePath);
        size = words.size();
    }

    public final void fillFromFile(String filePath) {
        try (Stream<String> stream = Files.lines(Paths.get(filePath))) {
            stream.forEach((String word) -> words.add(word));
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Couldn't read resource file!", e);
        }
    }
    
    public String getWord(int index){
        return words.get(index);
    }
    
    public int getSize() {
        return size;
    }
}
