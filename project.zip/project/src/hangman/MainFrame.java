/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangman;

import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

/**
 *
 * @author user
 */
public class MainFrame extends javax.swing.JFrame {


    
    Dictionary wordDictionary = new Dictionary();
    String currentWord;
    int currentWordIndex = -1;
    int triesLeft = 8;
    int lettersGuessed = 0;
    ArrayList<Integer> usedIndexes = new ArrayList<>();
    ArrayList<Character> chosenLetters = new ArrayList<>();
    Random rand = new Random();    
    
    public MainFrame() {
        initComponents();
        lblInfo.setText("Welcome to Hangman! Press New Word to begin the game.");
        txtInput.setEnabled(false);
        AbstractDocument document = (AbstractDocument) txtInput.getDocument();
        document.setDocumentFilter(new DocumentSizeFilter(1));
    }




    private void initComponents() {

        btnNewWord = new javax.swing.JButton();
        txtInput = new javax.swing.JTextField();
        lblInfo = new javax.swing.JLabel();
        lblWord = new javax.swing.JLabel();
        lblLetters = new javax.swing.JLabel();
        btnCheck = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Hangman");

        btnNewWord.setText("New Word");
        btnNewWord.setName("BtnNew"); // NOI18N
        btnNewWord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewWordActionPerformed(evt);
            }
        });

        txtInput.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtInput.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtInput.setName("txtInput"); // NOI18N

        lblInfo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblInfo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblInfo.setToolTipText("");
        lblInfo.setName("lblInfo"); // NOI18N

        lblWord.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblWord.setText("Word:");

        lblLetters.setText("Chosen letters: ");
        lblLetters.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        btnCheck.setText("Check Letter");
        btnCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCheckActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblLetters, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblWord, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtInput, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnCheck)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                        .addComponent(btnNewWord)))
                .addGap(42, 42, 42))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblWord, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLetters, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtInput, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCheck)
                    .addComponent(btnNewWord))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }

    private void btnNewWordActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
        takeNewWord();
        init();
    }

    private void btnCheckActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
        validateInput();        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }



        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainFrame().setVisible(true);
            }
        });
    }

    private void takeNewWord() {        
        do {
            currentWordIndex = rand.nextInt(wordDictionary.getSize());
        } while(usedIndexes.contains(currentWordIndex));
        usedIndexes.add(currentWordIndex);
        currentWord = wordDictionary.getWord(currentWordIndex);       

    }
    
    private void gameOver() {
        String wordLblStr = lblWord.getText();
        char[] wordLblCharArr = wordLblStr.toCharArray();
        for (int i = 6, j=0; i < wordLblCharArr.length ; i++,j++) {
            if(wordLblCharArr[i] == '_') {               
                wordLblCharArr[i] = currentWord.charAt(i-6-(j/2));                
            }
        }
        lblWord.setText(String.valueOf(wordLblCharArr));
        txtInput.setEnabled(false);     
    }

    private void validateInput() {
        char letter = txtInput.getText().charAt(0);
        if(Character.isLetter(letter) && Character.isLowerCase(letter) && !chosenLetters.contains(letter)) {
            lblLetters.setText(lblLetters.getText() + " " + letter);
            chosenLetters.add(letter);
            boolean letterFound = false;
            for (int i = 0; i < currentWord.length(); i++) {
                if(currentWord.charAt(i) == letter) {
                    letterFound = true;
                    char[] wordLblText = lblWord.getText().toCharArray();
                    wordLblText[6 + 2*i] = letter;
                    lblWord.setText(String.valueOf(wordLblText));
                    lettersGuessed++;
                    int lettersLeft = currentWord.length() - lettersGuessed;
                    if(lettersLeft == 0){
                        lblInfo.setText("Congratulations, you won! Press New Word for a new game.");
                        gameOver();
                    } else {                   
                         lblInfo.setText("Correct!You have " + lettersLeft + " letters "
                                + "and " + triesLeft + " tries left.");
                    }
                }
            }
            if(!letterFound){
                triesLeft--;
                if(triesLeft == 0) {
                    lblInfo.setText("Sorry, you failed! Press New Word for a new game.");
                    gameOver();
                } else {
                    int lettersLeft = (currentWord.length() - 1) - lettersGuessed;
                    lblInfo.setText("Incorrect! You have " + lettersLeft + " letters "
                            + "and " + triesLeft + " tries left.");
                }
            }
        }
        txtInput.setText("");
    }

    private void init() {
        chosenLetters = new ArrayList<>();
        triesLeft = 8;
        lettersGuessed = 0;
        txtInput.setEnabled(true);
        txtInput.setText("");
        lblWord.setText("Word:");
        for (int i = 0; i < currentWord.length(); i++) {
            lblWord.setText(lblWord.getText() + " _");
        }
        lblInfo.setText("New challenge arrives! You have " + currentWord.length() + " letters "
                                + "and " + triesLeft + " tries left.");
        lblLetters.setText("Chosen letters:");
    }
    

    private class DocumentSizeFilter extends DocumentFilter {
        int maxCharacters;

        public DocumentSizeFilter(int maxChars) {
            maxCharacters = maxChars;
        }

        @Override
        public void insertString(FilterBypass fb, int offs,
                                 String str, AttributeSet a)
            throws BadLocationException {
            if ((fb.getDocument().getLength() + str.length()) <= maxCharacters)
                super.insertString(fb, offs, str, a);
            else
                Toolkit.getDefaultToolkit().beep();
        }

        @Override
        public void replace(FilterBypass fb, int offs,
                            int length, 
                            String str, AttributeSet a)
            throws BadLocationException {
            if ((fb.getDocument().getLength() + str.length()
                 - length) <= maxCharacters)
                super.replace(fb, offs, length, str, a);
            else
                Toolkit.getDefaultToolkit().beep();
        }
    }
    

    private javax.swing.JButton btnCheck;
    private javax.swing.JButton btnNewWord;
    private javax.swing.JLabel lblInfo;
    private javax.swing.JLabel lblLetters;
    private javax.swing.JLabel lblWord;
    private javax.swing.JTextField txtInput;




}
